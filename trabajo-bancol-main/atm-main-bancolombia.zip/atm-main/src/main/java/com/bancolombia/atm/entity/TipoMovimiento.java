package com.bancolombia.atm.entity;

public enum TipoMovimiento {
    CONSULTA,
    RETIRO,
    TRANSFERENCIA,
    CONSIGNACION
}
