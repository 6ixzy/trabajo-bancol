package com.bancolombia.atm.entity;

public enum TipoCuenta {
    AHORROS,
    CORRIENTE,

}
